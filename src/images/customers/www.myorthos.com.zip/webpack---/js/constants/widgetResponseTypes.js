"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.HIDE_WIDGET = exports.V1 = void 0;
const V1 = 'V1';
exports.V1 = V1;
const HIDE_WIDGET = 'HIDE_WIDGET';
exports.HIDE_WIDGET = HIDE_WIDGET;