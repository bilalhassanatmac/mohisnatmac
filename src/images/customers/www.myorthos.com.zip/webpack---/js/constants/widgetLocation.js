"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.RIGHT_ALIGNED = exports.LEFT_ALIGNED = void 0;
const LEFT_ALIGNED = 'LEFT_ALIGNED';
exports.LEFT_ALIGNED = LEFT_ALIGNED;
const RIGHT_ALIGNED = 'RIGHT_ALIGNED';
exports.RIGHT_ALIGNED = RIGHT_ALIGNED;