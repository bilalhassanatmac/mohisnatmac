"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.CLEAR_PAGE_TITLE_NOTIFICATION = exports.SHOW_PAGE_TITLE_NOTIFICATION = void 0;
const SHOW_PAGE_TITLE_NOTIFICATION = 'show-page-title-notification';
exports.SHOW_PAGE_TITLE_NOTIFICATION = SHOW_PAGE_TITLE_NOTIFICATION;
const CLEAR_PAGE_TITLE_NOTIFICATION = 'clear-page-title-notification';
exports.CLEAR_PAGE_TITLE_NOTIFICATION = CLEAR_PAGE_TITLE_NOTIFICATION;