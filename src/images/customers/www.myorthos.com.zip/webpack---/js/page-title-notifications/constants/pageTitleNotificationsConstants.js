"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.NOTIFICATION_INTERVAL_MS = void 0;
const NOTIFICATION_INTERVAL_MS = 1250;
exports.NOTIFICATION_INTERVAL_MS = NOTIFICATION_INTERVAL_MS;