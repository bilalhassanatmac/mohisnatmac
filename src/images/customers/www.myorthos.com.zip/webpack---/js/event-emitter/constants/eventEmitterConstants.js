"use strict";
'use es6';

Object.defineProperty(exports, "__esModule", {
    value: true
});
exports.EVENT_NAMESPACE = void 0;
const EVENT_NAMESPACE = 'HubSpotConversations';
exports.EVENT_NAMESPACE = EVENT_NAMESPACE;